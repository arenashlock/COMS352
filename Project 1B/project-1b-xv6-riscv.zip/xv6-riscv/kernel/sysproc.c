#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Project 1B addition
uint64 sys_getppid(void) {
  /*TODO:
    (1) call myproc() to get the caller’s struct proc
    (2) follow the field “parent” in the struct proc to find the parent’s struct proc
    (3) in the parent’s struct proc, find the pid and return it
  */

  // Get the current running process
  struct proc *p = myproc();

  // Check if there is a parent (return ppid if there is, 0 if not)
  if(p->parent) {
    return p->parent->pid;
  } else {
    return 0;
  }
}



extern struct proc proc[NPROC]; //declare array proc which is defined in proc.c already

uint64 sys_ps(void) {
  //define the ps_struct for each process and ps[NPROC] for all processes
  struct ps_struct{
    int pid;
    int ppid;
    char state[10];
    char name[16];
  } ps[NPROC];

  int numProc = 0; //variable keeping track of the number of processes in the system

  /*  To do: From array proc, find the processes that are still in the system (i.e.,
      their states are not NUNUSED. For each of the process, retrieve the
      information and put into a ps_struct defined above  */

  // Iterate through the array of proc
  for(int i = 0; i < NPROC; i++) {
    // Check that the state is NOT unused
    if(proc[i].state != UNUSED) {
      // Save the similar information found in the proc struct
      ps[numProc].pid = proc[i].pid;

      // If there is a parent, get the pid (the ppid), else it should be 0
      if(proc[i].parent) {
        ps[numProc].ppid = proc[i].parent->pid;
      } else {
        ps[numProc].ppid = 0;
      }

      // I HAD ISSUES WITH STRCPY, so I just used this non-efficient approach to make the strings...
      for(int j = 0; j < 16; j++) {
        ps[numProc].name[j] = proc[i].name[j];
      }

      // Run through the enums to determine the state and save the string describing it
      // I HAD ISSUES WITH STRCPY, so I just used this non-efficient approach to make the strings...
      if(proc[i].state == USED) {
        ps[numProc].state[0] = 'U';
        ps[numProc].state[1] = 'S';
        ps[numProc].state[2] = 'E';
        ps[numProc].state[3] = 'D';
        ps[numProc].state[4] = '\0';
      } else if(proc[i].state == SLEEPING) {
        ps[numProc].state[0] = 'S';
        ps[numProc].state[1] = 'L';
        ps[numProc].state[2] = 'E';
        ps[numProc].state[3] = 'E';
        ps[numProc].state[4] = 'P';
        ps[numProc].state[5] = 'I';
        ps[numProc].state[6] = 'N';
        ps[numProc].state[7] = 'G';
        ps[numProc].state[8] = '\0';
      } else if(proc[i].state == RUNNABLE) {
        ps[numProc].state[0] = 'R';
        ps[numProc].state[1] = 'U';
        ps[numProc].state[2] = 'N';
        ps[numProc].state[3] = 'N';
        ps[numProc].state[4] = 'A';
        ps[numProc].state[5] = 'B';
        ps[numProc].state[6] = 'L';
        ps[numProc].state[7] = 'E';
        ps[numProc].state[8] = '\0';
      } else if(proc[i].state == RUNNING) {
        ps[numProc].state[0] = 'R';
        ps[numProc].state[1] = 'U';
        ps[numProc].state[2] = 'N';
        ps[numProc].state[3] = 'N';
        ps[numProc].state[4] = 'I';
        ps[numProc].state[5] = 'N';
        ps[numProc].state[6] = 'G';
        ps[numProc].state[7] = '\0';
      } else {
        ps[numProc].state[0] = 'Z';
        ps[numProc].state[1] = 'O';
        ps[numProc].state[2] = 'M';
        ps[numProc].state[3] = 'B';
        ps[numProc].state[4] = 'I';
        ps[numProc].state[5] = 'E';
        ps[numProc].state[6] = '\0';
      }

      // Increment the total number of processes (for the return value and ps iteration)
      numProc += 1;
    }
  }
  
  //save the address of the user space argment to arg_addr
  uint64 arg_addr;
  argaddr(0, &arg_addr);

  //copy array ps to the saved address
  if (copyout(myproc()->pagetable, arg_addr, (char *) ps, numProc * sizeof(struct ps_struct)) < 0)
    return -1;

  //return numProc as well
  return numProc;
}



uint64 sys_getschedhistory(void) {
  //define the struct for reporting scheduling history
  struct sched_history{
    int runCount;
    int systemcallCount;
    int interruptCount;
    int preemptCount;
    int trapCount;
    int sleepCount;
  } my_history;

  //To do: retrieve the current process’ information to fill my_history
  // Get the current process and set all the values in the struct
  struct proc *p = myproc();
  my_history.runCount = p->runCount;
  my_history.systemcallCount = p->systemcallCount;
  my_history.interruptCount = p->interruptCount;
  my_history.preemptCount = p->preemptCount;
  my_history.trapCount = p->trapCount;
  my_history.sleepCount = p->sleepCount;

  //save the address of the user space argment to arg_addr
  uint64 arg_addr;
  argaddr(0, &arg_addr);

  //To do: copy the content in my_history to the saved address
  if (copyout(p->pagetable, arg_addr, (char *) &my_history, sizeof(struct sched_history)) < 0)
    return -1;

  //To do: return the pid as well
  return p->pid;
}