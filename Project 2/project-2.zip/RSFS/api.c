/*
    implementation of API
*/

#include "def.h"

pthread_mutex_t mutex_for_fs_stat;

/* 
    MAIN IDEA: Initialize file system - should be called as the first thing before accessing this file system
*/
int RSFS_init() {
    // initialize data blocks
    for(int i = 0; i < NUM_DBLOCKS; i++) {
        // a data block is allocated from memory
        void *block = malloc(BLOCK_SIZE);
        
        if(block == NULL) {
            printf("[init] fails to init data_blocks\n");
            return -1;
        }
      
        data_blocks[i] = block;  
    } 

    // initialize bitmaps
    for(int i = 0; i < NUM_DBLOCKS; i++) data_bitmap[i] = 0;
    pthread_mutex_init(&data_bitmap_mutex, NULL);
    for(int i = 0; i < NUM_INODES; i++) inode_bitmap[i] = 0;
    pthread_mutex_init(&inode_bitmap_mutex, NULL);    

    // initialize inodes
    for(int i = 0; i < NUM_INODES; i++) {
        inodes[i].length = 0;

        for(int j = 0; j < NUM_POINTER; j++) 
            // pointer value -1 means the pointer is not used
            inodes[i].block[j] = -1;
        
        inodes[i].num_current_reader = 0;
        pthread_mutex_init(&inodes[i].rw_mutex, NULL);
        pthread_mutex_init(&inodes[i].read_mutex, NULL);
    }
    pthread_mutex_init(&inodes_mutex, NULL); 

    // initialize open file table
    for(int i = 0; i < NUM_OPEN_FILE; i++){
        struct open_file_entry entry = open_file_table[i];
        // each entry is not used initially
        entry.used = 0;
        pthread_mutex_init(&entry.entry_mutex, NULL);
        entry.position = 0;
        entry.access_flag = -1;
    }
    pthread_mutex_init(&open_file_table_mutex, NULL); 

    // initialize root directory
    root_dir.head = root_dir.tail = NULL;

    // initialize mutex_for_fs_stat
    pthread_mutex_init(&mutex_for_fs_stat, NULL);

    // return 0 means success
    return 0;
}

/* 
    MAIN IDEA: Create file
        if file does not exist, create the file and return 0;
        if file_name already exists, return -1; 
        otherwise, return -2.
*/
int RSFS_create(char *file_name) {
    // search root_dir for dir_entry matching provided file_name
    struct dir_entry *dir_entry = search_dir(file_name);

    // already exists
    if(dir_entry) {
        printf("[create] file (%s) already exists.\n", file_name);
        return -1;
    } else {
        if(DEBUG) printf("[create] file (%s) does not exist.\n", file_name);

        // construct and insert a new dir_entry with given file_name
        dir_entry = insert_dir(file_name);
        if(DEBUG) printf("[create] insert a dir_entry with file_name:%s.\n", dir_entry->name);
        
        // access inode-bitmap to get a free inode 
        int inode_number = allocate_inode();
        if(inode_number < 0) {
            printf("[create] fail to allocate an inode.\n");
            return -2;
        }

        if(DEBUG) printf("[create] allocate inode with number:%d.\n", inode_number);

        // save inode-number to dir-entry
        dir_entry->inode_number = inode_number;
        
        return 0;
    }
}

/*
    MAIN IDEA: Open a file with RSFS_RDONLY or RSFS_RDWR flags                                                                                         DONE
        when flag = RSFS_RDONLY: 
            if the file is currently opened with RSFS_RDWR (by a process/thread) => the caller should be blocked (wait); 
            otherwise, the file is opened and the descriptor (i.e., index of the open_file_entry in the open_file_table) is returned
        when flag = RSFS_RDWR:
            if the file is currently opened with RSFS_RDWR (by a process/thread) or RSFS_RDONLY (by one or multiple processes/threads)
               => the caller should be blocked (i.e. wait);
            otherwise, the file is opened and the desrcriptor is returned
*/
int RSFS_open(char *file_name, int access_flag) {
    // Check to make sure access_flag is either RSFS_RDONLY or RSFS_RDWR
    if(access_flag != RSFS_RDONLY && access_flag != RSFS_RDWR)
        return -1;

    // Find dir_entry matching file_name
    struct dir_entry *dir_entry = search_dir(file_name);

    // Find the corresponding inode 
    struct inode *inode = &inodes[dir_entry->inode_number];
    
    // Check the access_flag to see whether reader or writer obtains the mutex to solve the reader/writer problem
    if(access_flag == RSFS_RDONLY) {
        pthread_mutex_lock(&inode->read_mutex);
        inode->num_current_reader++;
        if(inode->num_current_reader == 1) {
            pthread_mutex_lock(&inode->rw_mutex);
        }
        pthread_mutex_unlock(&inode->read_mutex);
    } else {
        pthread_mutex_lock(&inode->rw_mutex);
    }

    // Find an unused open file entry in the open file table and fill the fields of the entry properly
    int fd = allocate_open_file_entry(access_flag, dir_entry);

    // Return the index of the open file entry as a file descriptor
    return fd;
}

/*
    MAIN IDEA: Append the content in buf to the end of the file of descriptor fd
*/
int RSFS_append(int fd, void *buf, int size) {
    // Check the sanity of the arguments: fd should be in [0, NUM_OPEN_FILE) and size > 0.
    if((fd < 0 || fd >= NUM_OPEN_FILE) || size <= 0)
        return -1;

    // Get the open file entry corresponding to fd
    struct open_file_entry *open_file_entry = &open_file_table[fd];

    // Check if the file is opened with RSFS_RDWR mode; otherwise return -1
    if(open_file_entry->access_flag != RSFS_RDWR)
        return -1;

    // Get the current position
    int position = open_file_entry->position;

    // Get the directory entry for the open file
    struct dir_entry *dir_entry = open_file_entry->dir_entry;

    // Get the inode for the directory entry
    struct inode *inode = &inodes[dir_entry->inode_number];

    // Set the position to be the end of the file
    position = inode->length;

    // Variable to help make sure all of the buf gets appended
    int appendSize = 0;

    // While there is still something left to be appended
    while(appendSize < size) {
        // At the start of a new data block, allocate a new one
        if(position % BLOCK_SIZE == 0) {
            int success = inode->block[position / BLOCK_SIZE] = allocate_data_block();

            // Check to make sure a new data block was allocated, otherwise the rest of buf can't be appended (break)
            if(success == -1) {
                break;
            }
        }
        
        // Variables for making sure to copy only what's allowed into the data block
        int memmoveSize = size - appendSize;
        int dataBlockSpace = BLOCK_SIZE - (position % BLOCK_SIZE);

        // Check if trying to copy more to the data block than there is space
        if(memmoveSize > dataBlockSpace) {
            memmoveSize = dataBlockSpace;
        }

        // Copy the contents of buf (with the correct offset and size) to the data block
        memmove(data_blocks[inode->block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), buf + appendSize, memmoveSize);

        // Update the position and appendSize to correctly add further stuff to the data blocks
        position += memmoveSize;
        appendSize += memmoveSize;
    }
     
    // Update the position of the file entry
    pthread_mutex_lock(&open_file_entry->entry_mutex);
    open_file_entry->position = position;
    pthread_mutex_unlock(&open_file_entry->entry_mutex);

    // Update the length of the inode
    pthread_mutex_lock(&inodes_mutex);
    inode->length += appendSize;
    pthread_mutex_unlock(&inodes_mutex);
    
    // Return the number of bytes appended to the file
    return appendSize;
}

/*
    MAIN IDEA: Update current position of the file (which is in the open_file_entry) to offset
*/
int RSFS_fseek(int fd, int offset) {
    // Sanity test of fd    
    if(fd < 0 || fd >= NUM_OPEN_FILE)
        return -1;

    // Get the corresponding open file entry
    struct open_file_entry *open_file_entry = &open_file_table[fd];

    // Get the current position
    int position = open_file_entry->position;

    // Get the corresponding dir entry
    struct dir_entry *dir_entry = open_file_entry->dir_entry;

    // Get the corresponding inode and file length
    struct inode inode = inodes[dir_entry->inode_number];
    int length = inode.length;

    // Check if offset is not within 0...length, do not proceed and return current position
    if(offset < 0 && offset > length)
        return position;

    // Update the current position to offset, and return the new current position
    position = offset;
    pthread_mutex_lock(&open_file_entry->entry_mutex);
    open_file_entry->position = position;
    pthread_mutex_unlock(&open_file_entry->entry_mutex);

    // Return the current poisiton
    return position;
}

/*
    MAIN IDEA: Read from file from the current position for up to size bytes
*/
int RSFS_read(int fd, void *buf, int size) {
    // Sanity test of fd and size    
    if((fd < 0 || fd >= NUM_OPEN_FILE) || size <= 0)
        return -1;

    // Get the corresponding open file entry
    struct open_file_entry *open_file_entry = &open_file_table[fd];

    // Get the current position
    int position = open_file_entry->position;

    // Get the corresponding directory entry
    struct dir_entry *dir_entry = open_file_entry->dir_entry;

    // Get the corresponding inode 
    struct inode inode = inodes[dir_entry->inode_number];

    // Keep track of the actual number of bytes read for the return value
    int actualBytesRead = 0;

    // Loop through each block to get all the data
    while(actualBytesRead < size) {
        // At the end of the file, break out of the loop even if not all the specified size has been read
        if(position == inode.length) {
            break;
        }

        // Set the size for memmove to be from the position to the end of the data block by default
        int memmoveSize = BLOCK_SIZE - (position % BLOCK_SIZE);

        // If that's more than the amount of bytes left to be read, go with the smaller value
        if(memmoveSize > (size - actualBytesRead)) {
            memmoveSize = size - actualBytesRead;
        } else if(memmoveSize > (inode.length - position)) { // OR, if that's more than the amount of bytes left in the data block, go with the smaller value
            memmoveSize = inode.length - position;
        }

        // Copy the contents from the data block to the buf
        memmove(buf + actualBytesRead, data_blocks[inode.block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), memmoveSize);

        // Update the position and actualBytesRead to correctly read stuff in other data blocks
        position += memmoveSize;
        actualBytesRead += memmoveSize;
    }

    // Update the current position in open file entry
    pthread_mutex_lock(&open_file_entry->entry_mutex);
    open_file_entry->position = position;
    pthread_mutex_unlock(&open_file_entry->entry_mutex);

    // Return the actual number of bytes read
    return actualBytesRead;
}

/*
    MAIN IDEA: Close file - return 0 if succeed                                                                                                        DONE
*/
int RSFS_close(int fd) {
    // Sanity test of fd   
    if(fd < 0 || fd >= NUM_OPEN_FILE)
        return -1;

    // Get the corresponding open file entry
    struct open_file_entry open_file_entry = open_file_table[fd];

    // Get the corresponding dir entry
    struct dir_entry *dir_entry = open_file_entry.dir_entry;

    // Get the corresponding inode 
    struct inode *inode = &inodes[dir_entry->inode_number];

    // Properly give up mutex(es) depending on the mode that obtained the mutex in the first place
    if(open_file_entry.access_flag == RSFS_RDONLY) {
        pthread_mutex_lock(&inode->read_mutex);
        inode->num_current_reader--;
        if(inode->num_current_reader == 0) {
            pthread_mutex_unlock(&inode->rw_mutex);
        }
        pthread_mutex_unlock(&inode->read_mutex);
    } else {
        pthread_mutex_unlock(&inode->rw_mutex);
    }

    // Release this open file entry in the open file table
    free_open_file_entry(fd);

    // Return 0 for succeeding
    return 0;
}

/*
    MAIN IDEA: Delete file                                                                                                                             DONE
*/
int RSFS_delete(char *file_name) {
    // Find the corresponding dir_entry
    struct dir_entry *dir_entry = search_dir(file_name);

    // Find the corresponding inode
    struct inode *inode = &inodes[dir_entry->inode_number];

    for(int i = 0; inode->block[i] != -1; i++) {
        free_data_block(inode->block[i]);
    }

    // Free the inode in inode-bitmap
    free_inode(dir_entry->inode_number);

    delete_dir(file_name);

    return 0;
}

/*
    MAIN IDEA: Print status of the file system
*/
void RSFS_stat() {
    pthread_mutex_lock(&mutex_for_fs_stat);

    printf("\nCurrent status of the file system:\n\n %16s%10s%10s\n", "File Name", "Length", "iNode #");

    // list files
    struct dir_entry *dir_entry = root_dir.head;
    while(dir_entry != NULL) {
        int inode_number = dir_entry->inode_number;
        struct inode *inode = &inodes[inode_number];
        
        printf("%16s%10d%10d\n", dir_entry->name, inode->length, inode_number);
        dir_entry = dir_entry->next;
    }
    
    // data blocks
    int db_used = 0;
    for(int i = 0; i < NUM_DBLOCKS; i++) db_used += data_bitmap[i];
    printf("\nTotal Data Blocks: %4d,  Used: %d,  Unused: %d\n", NUM_DBLOCKS, db_used, NUM_DBLOCKS - db_used);

    // inodes
    int inodes_used = 0;
    for(int i = 0; i < NUM_INODES; i++) inodes_used += inode_bitmap[i];
    printf("Total iNode Blocks: %3d,  Used: %d,  Unused: %d\n", NUM_INODES, inodes_used, NUM_INODES - inodes_used);

    // open files
    int of_num = 0;
    for(int i = 0; i < NUM_OPEN_FILE; i++) of_num += open_file_table[i].used;
    printf("Total Opened Files: %3d\n\n", of_num);

    pthread_mutex_unlock(&mutex_for_fs_stat);
}

/*
    MAIN IDEA: Write the content of size (bytes) in buf to the file (of descripter fd) from current position for up to size bytes
*/
int RSFS_write(int fd, void *buf, int size) {
    // Sanity test of fd and size    
    if((fd < 0 || fd >= NUM_OPEN_FILE) || size <= 0)
        return -1;

    // Get the corresponding open file entry
    struct open_file_entry *open_file_entry = &open_file_table[fd];

    // Get the current position
    int position = open_file_entry->position;

    // Get the corresponding directory entry
    struct dir_entry *dir_entry = open_file_entry->dir_entry;

    // Get the corresponding inode 
    struct inode *inode = &inodes[dir_entry->inode_number];

    // Variable to help make sure all of the buf gets written
    int writeSize = 0;

    // While there is still something left to be written
    while(writeSize < size) {
        // At the start of a new data block, allocate a new one (assuming it hasn't been allocated one yet)
        if(position % BLOCK_SIZE == 0 && inode->block[position / BLOCK_SIZE] == -1) {
            int success = inode->block[position / BLOCK_SIZE] = allocate_data_block();

            // Check to make sure a new data block was allocated, otherwise the rest of buf can't be fully written (break)
            if(success == -1) {
                break;
            }
        }
        
        // Variables for making sure to copy only what's allowed into the data block
        int memmoveSize = size - writeSize;
        int dataBlockSpace = BLOCK_SIZE - (position % BLOCK_SIZE);

        // Check if trying to copy more to the data block than there is space
        if(memmoveSize > dataBlockSpace) {
            memmoveSize = dataBlockSpace;
        }

        // Copy the contents of buf (with the correct offset and size) to the data block
        memmove(data_blocks[inode->block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), buf + writeSize, memmoveSize);

        // Update the position and appendSize to correctly write the rest of the content to the data blocks
        position += memmoveSize;
        writeSize += memmoveSize;
    }

    // The position after the main write function will be the new length of the inode and the new position of the open_file_entry
    int newLength = position;

    // Remove the garbage from the datablocks and free any unused blocks
    while(position < inode->length) {
        // At the start of a new data block, free it since it won't be used anymore
        if(position % BLOCK_SIZE == 0) {
            free_data_block(inode->block[position / BLOCK_SIZE]);
        }

        // Set unused data block contents to null
        memmove(data_blocks[inode->block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), "\0", 1);

        // Move forward in the process
        position++;
    }
     
    // Update the position of the file entry
    pthread_mutex_lock(&open_file_entry->entry_mutex);
    open_file_entry->position = newLength;
    pthread_mutex_unlock(&open_file_entry->entry_mutex);

    // Update the length of the inode
    pthread_mutex_lock(&inodes_mutex);
    inode->length = newLength;
    pthread_mutex_unlock(&inodes_mutex);

    // Return the number of bytes written to the file
    return writeSize;
}

/*
    MAIN IDEA: Cut the content from the current position for up to size (bytes) from the file of descriptor fd
*/
int RSFS_cut(int fd, int size) {
    // Sanity test of fd and size    
    if((fd < 0 || fd >= NUM_OPEN_FILE) || size <= 0)
        return -1;

    // Get the corresponding open file entry
    struct open_file_entry *open_file_entry = &open_file_table[fd];

    // Get the current position
    int position = open_file_entry->position;

    // Get the corresponding directory entry
    struct dir_entry *dir_entry = open_file_entry->dir_entry;

    // Get the corresponding inode 
    struct inode *inode = &inodes[dir_entry->inode_number];
    int inodeLength = inode->length;

    // Variable to help make sure all of the buf gets written (default to the specified size)
    int cutSize = size;
    
    // Check to see the proper amount that can be cut, if asking for more, then set to the amount it can cut
    if(cutSize > (inodeLength - position)) {
        cutSize = (inodeLength - position);
    }

    // While there is still something left to be cut
    while(position < (inodeLength - cutSize)) {
        // As default, plan to copy all the contents from the offset position to the max size of a data block
        int memmoveSize = inodeLength - (position + cutSize);
        
        // Check to make sure it's not trying to copy more than it has space for in the current data block
        if(memmoveSize > (BLOCK_SIZE - (position % BLOCK_SIZE))) {
            memmoveSize = BLOCK_SIZE - (position % BLOCK_SIZE);
        }

        // Check to make sure it's not trying to copy more than there is in the "future" data block
        if(memmoveSize > (BLOCK_SIZE - ((position + cutSize) % BLOCK_SIZE))) {
            memmoveSize = BLOCK_SIZE - ((position + cutSize) % BLOCK_SIZE);
        }

        // Copy the contents of buf (with the correct offset and size) to the data block
        memmove(data_blocks[inode->block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), data_blocks[inode->block[(position + cutSize) / BLOCK_SIZE]] + ((position + cutSize) % BLOCK_SIZE), memmoveSize);

        // Update the position to correctly keep cutting stuff after the size
        position += memmoveSize;
    }

    // Remove the garbage from the datablocks and free any unused blocks (essentially completing the "cut")
    while(position < inode->length) {
        // At the start of a new data block, free it since it won't be used anymore
        if(position % BLOCK_SIZE == 0) {
            free_data_block(inode->block[position / BLOCK_SIZE]);
        }

        // Set unused data block contents to null
        memmove(data_blocks[inode->block[position / BLOCK_SIZE]] + (position % BLOCK_SIZE), "\0", 1);

        // Move forward in the process
        position++;
    }

    // The new length after the cut function
    int newLength = inodeLength - cutSize;

    // Update the length of the inode
    pthread_mutex_lock(&inodes_mutex);
    inode->length = newLength;
    pthread_mutex_unlock(&inodes_mutex);

    // Return the number of bytes written to the file
    return cutSize;
}